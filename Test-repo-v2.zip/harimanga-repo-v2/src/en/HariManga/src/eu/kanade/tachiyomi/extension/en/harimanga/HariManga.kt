package eu.kanade.tachiyomi.extension.en.harimanga

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.network.POST
import eu.kanade.tachiyomi.source.model.Filter
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.ParsedHttpSource
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Locale

class HariManga : ParsedHttpSource() {

    // ─── Identity ────────────────────────────────────────────────────────────
    override val name    = "HariManga"
    override val baseUrl = "https://harimanga.me"
    override val lang    = "en"
    override val supportsLatest = true

    override val client: OkHttpClient = network.cloudflareClient

    // ─── Popular ─────────────────────────────────────────────────────────────
    override fun popularMangaRequest(page: Int): Request =
        GET("$baseUrl/manga/?page=$page&order=popular", headers)

    override fun popularMangaSelector()              = "div.bs div.bsx"
    override fun popularMangaNextPageSelector()      = "a.next.page-numbers"

    override fun popularMangaFromElement(element: Element) = SManga.create().apply {
        val a = element.selectFirst("a")!!
        setUrlWithoutDomain(a.attr("href"))
        title       = element.selectFirst("div.tt, .series-title")?.text()
                      ?: a.attr("title")
        thumbnail_url = element.selectFirst("img")?.let {
            it.attr("abs:src").ifEmpty { it.attr("abs:data-src") }
        }
    }

    // ─── Latest ──────────────────────────────────────────────────────────────
    override fun latestUpdatesRequest(page: Int): Request =
        GET("$baseUrl/manga/?page=$page&order=update", headers)

    override fun latestUpdatesSelector()         = popularMangaSelector()
    override fun latestUpdatesNextPageSelector() = popularMangaNextPageSelector()
    override fun latestUpdatesFromElement(element: Element) = popularMangaFromElement(element)

    // ─── Search ──────────────────────────────────────────────────────────────
    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val url = "$baseUrl/manga/".toHttpUrl().newBuilder().apply {
            if (query.isNotBlank()) addQueryParameter("s", query)
            addQueryParameter("page", page.toString())
            filters.forEach { filter ->
                when (filter) {
                    is GenreFilter -> if (filter.state != 0)
                        addQueryParameter("genre", filter.values[filter.state].second)
                    is StatusFilter -> if (filter.state != 0)
                        addQueryParameter("status", filter.values[filter.state].second)
                    is OrderFilter -> if (filter.state != 0)
                        addQueryParameter("order", filter.values[filter.state].second)
                    else -> {}
                }
            }
        }.build()
        return GET(url.toString(), headers)
    }

    override fun searchMangaSelector()         = popularMangaSelector()
    override fun searchMangaNextPageSelector() = popularMangaNextPageSelector()
    override fun searchMangaFromElement(element: Element) = popularMangaFromElement(element)

    // ─── Manga details ────────────────────────────────────────────────────────
    override fun mangaDetailsParse(document: Document) = SManga.create().apply {
        thumbnail_url = document.selectFirst("div.thumb img")?.let {
            it.attr("abs:src").ifEmpty { it.attr("abs:data-src") }
        }
        title       = document.selectFirst("h1.entry-title")?.text() ?: ""
        author      = document.selectFirst("span.imptdt:contains(Author) i, .tsinfo .imptdt:contains(Author) a")
                        ?.text()
        artist      = document.selectFirst("span.imptdt:contains(Artist) i, .tsinfo .imptdt:contains(Artist) a")
                        ?.text()
        description = document.selectFirst("div.entry-content[itemprop=description], div.summary p")
                        ?.text()
        genre       = document.select("div.gnr a, span.mgen a").joinToString { it.text() }
        status      = when (
            document.selectFirst("span.imptdt:contains(Status) i")?.text()?.lowercase()
        ) {
            "ongoing"   -> SManga.ONGOING
            "completed" -> SManga.COMPLETED
            "hiatus"    -> SManga.ON_HIATUS
            else        -> SManga.UNKNOWN
        }
    }

    // ─── Chapter list ─────────────────────────────────────────────────────────
    override fun chapterListSelector() = "div#chapterlist li"

    override fun chapterFromElement(element: Element) = SChapter.create().apply {
        val a = element.selectFirst("a")!!
        setUrlWithoutDomain(a.attr("href"))
        name         = element.selectFirst("span.chapternum")?.text() ?: a.text()
        date_upload  = element.selectFirst("span.chapterdate")?.text()
                         ?.let { parseDate(it) } ?: 0L
    }

    private fun parseDate(raw: String): Long {
        return runCatching {
            SimpleDateFormat("MMMM d, yyyy", Locale.US).parse(raw.trim())?.time ?: 0L
        }.getOrDefault(0L)
    }

    // ─── Page list ────────────────────────────────────────────────────────────
    override fun pageListParse(document: Document): List<Page> {
        return document.select("div#readerarea img[src], div#readerarea img[data-src]")
            .mapIndexed { i, img ->
                val url = img.attr("abs:src").ifEmpty { img.attr("abs:data-src") }
                Page(i, "", url)
            }
    }

    override fun imageUrlParse(document: Document) = ""

    // ─── Filters ──────────────────────────────────────────────────────────────
    private class GenreFilter : SelectFilter(
        "Genre",
        arrayOf(
            Pair("Any", ""),
            Pair("Action", "action"),
            Pair("Adventure", "adventure"),
            Pair("Comedy", "comedy"),
            Pair("Drama", "drama"),
            Pair("Fantasy", "fantasy"),
            Pair("Horror", "horror"),
            Pair("Isekai", "isekai"),
            Pair("Martial Arts", "martial-arts"),
            Pair("Mature", "mature"),
            Pair("Mystery", "mystery"),
            Pair("Romance", "romance"),
            Pair("School Life", "school-life"),
            Pair("Sci-fi", "sci-fi"),
            Pair("Seinen", "seinen"),
            Pair("Shoujo", "shoujo"),
            Pair("Shounen", "shounen"),
            Pair("Slice of Life", "slice-of-life"),
            Pair("Sports", "sports"),
            Pair("Supernatural", "supernatural"),
            Pair("Tragedy", "tragedy"),
        )
    )

    private class StatusFilter : SelectFilter(
        "Status",
        arrayOf(
            Pair("Any", ""),
            Pair("Ongoing", "ongoing"),
            Pair("Completed", "completed"),
            Pair("Hiatus", "hiatus"),
        )
    )

    private class OrderFilter : SelectFilter(
        "Order By",
        arrayOf(
            Pair("Default", ""),
            Pair("A–Z", "title"),
            Pair("Z–A", "titlereverse"),
            Pair("Latest Update", "update"),
            Pair("Latest Added", "latest"),
            Pair("Popular", "popular"),
            Pair("Rating", "rating"),
        )
    )

    open class SelectFilter(
        name: String,
        val values: Array<Pair<String, String>>,
        state: Int = 0,
    ) : Filter.Select<String>(name, values.map { it.first }.toTypedArray(), state)

    override fun getFilterList() = FilterList(
        Filter.Header("Filters are ignored when using text search"),
        GenreFilter(),
        StatusFilter(),
        OrderFilter(),
    )
}
